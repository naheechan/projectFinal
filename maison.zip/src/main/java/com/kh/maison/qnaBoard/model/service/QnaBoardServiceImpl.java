package com.kh.maison.qnaBoard.model.service;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.kh.maison.qnaBoard.model.dao.QnaBoardDao;
import com.kh.maison.qnaBoard.model.vo.QnaBoardVo;

@Service
public class QnaBoardServiceImpl implements QnaBoardService{
	
	@Autowired
	private QnaBoardDao dao;
	@Autowired
	private SqlSession session;
	
	public int insertQnaBoard(QnaBoardVo QB){
		System.out.println("service~~~~~~~~~~~~~~~~~~~~~~~~~");
		int result=dao.insertQnaBoard(session,QB);
		return result; 
	}

	@Override
	public List<QnaBoardVo> selectList() {
		// TODO Auto-generated method stub
		return dao.selectList(session);
	}

	@Override
	public QnaBoardVo selectQna(int no) {
		
		return dao.selectQna(session,no);
	}
	
	
	
}
