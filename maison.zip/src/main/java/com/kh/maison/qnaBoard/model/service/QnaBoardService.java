package com.kh.maison.qnaBoard.model.service;

import java.util.List;

import com.kh.maison.qnaBoard.model.vo.QnaBoardVo;

public interface QnaBoardService {
	
	List<QnaBoardVo> selectList();
	
	int insertQnaBoard(QnaBoardVo QB);
	
	QnaBoardVo selectQna(int no);

}
