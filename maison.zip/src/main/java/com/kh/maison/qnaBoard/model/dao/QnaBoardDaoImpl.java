package com.kh.maison.qnaBoard.model.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.kh.maison.qnaBoard.model.vo.QnaBoardVo;
@Repository
public class QnaBoardDaoImpl implements QnaBoardDao{

	public int insertQnaBoard(SqlSession session,QnaBoardVo QB) {
		System.out.println("dao~~~~~~~~~~~~~~~~~~~~~~~~~");
		return session.insert("qnaBoard.insertQnaBoard",QB);
	}

	@Override
	public List<QnaBoardVo> selectList(SqlSession session) {
		// TODO Auto-generated method stub
		return session.selectList("qnaBoard.selectList");
	}

	@Override
	public QnaBoardVo selectQna(SqlSession session, int no) {
		// TODO Auto-generated method stub
		return session.selectOne("qnaBoard.selectQna",no);
	}
	
	

}
